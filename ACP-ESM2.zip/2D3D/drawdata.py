import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# 读取数据文件
data = pd.read_excel('data.xlsx')

# 提取X、Y、Z和label列
x_values = data['X']
y_values = data['Y']
z_values = data['Z']
labels = data['label']

# 画二维图
plt.figure(figsize=(8, 6))
plt.scatter(x_values, y_values, c=labels, cmap='viridis')
plt.title('2D Scatter Plot')
plt.xlabel('X')
plt.ylabel('Y')
plt.show()

# 画三维图
fig = plt.figure(figsize=(8, 6))
ax = fig.add_subplot(111, projection='3d')
ax.scatter(x_values, y_values, z_values, c=labels, cmap='viridis')
ax.set_title('3D Scatter Plot')
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
plt.show()
