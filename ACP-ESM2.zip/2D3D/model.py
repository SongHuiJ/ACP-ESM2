import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim

# 读取数据
from sklearn.model_selection import train_test_split
from torch.utils.data import TensorDataset, DataLoader

# 读取数据
df = pd.read_excel('data.xlsx')
X = df[['X', 'Y']].values.astype(np.float32)
y = df[['X', 'Y', 'Z']].values.astype(np.float32)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 转换数据为PyTorch的Tensor
X_train_tensor = torch.from_numpy(X_train)
y_train_tensor = torch.from_numpy(y_train)
X_test_tensor = torch.from_numpy(X_test)
y_test_tensor = torch.from_numpy(y_test)

# 创建数据集和数据加载器
train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
test_dataset = TensorDataset(X_test_tensor, y_test_tensor)

batch_size = 1
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)


# 定义神经网络模型
class MyModel(nn.Module):
    def __init__(self):
        super(MyModel, self).__init__()
        self.fc1 = nn.Linear(2, 64)  # 输入维度为2，输出维度为64
        self.fc2 = nn.Linear(64, 64)  # 输入维度为64，输出维度为64
        self.fc3 = nn.Linear(64, 3)  # 输入维度为64，输出维度为3，对应三维坐标点

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x


# 实例化模型
model = MyModel()

# 定义损失函数和优化器
criterion = nn.MSELoss()  # 均方误差损失函数
optimizer = optim.Adam(model.parameters(), lr=5e-4)  # Adam优化器

# 假设你的输入数据为二维坐标点，输出数据为三维坐标点
# X_train是输入数据，Y_train是对应的输出数据
# 这里的X_train和Y_train是你的训练数据，你需要根据自己的数据来替换它们
# 你可以通过读取数据文件或者生成数据来获取这些数据
# 然后使用X_train和Y_train来训练你的模型
for epoch in range(500):  # 假设训练10个epoch
    running_loss = 0.0
    for inputs, labels in train_loader:  # 假设使用一个train_loader来加载训练数据
        # 将输入和标签转换为PyTorch张量
        inputs, labels = torch.tensor(inputs), torch.tensor(labels)

        # 清除梯度
        optimizer.zero_grad()

        # 正向传播
        outputs = model(inputs)
        loss = criterion(outputs, labels)

        # 反向传播和优化
        loss.backward()
        optimizer.step()

        running_loss += loss.item()
    print('Epoch [%d/%d], Loss: %.4f' % (epoch + 1, 10, running_loss))
    # 假设model是你训练好的模型
    torch.save(model.state_dict(), 'model_weights.pth')



