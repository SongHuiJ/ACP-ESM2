import numpy as np
import pandas as pd
import torch
import torch.nn as nn

# 读取数据
from sklearn.model_selection import train_test_split
from torch.utils.data import TensorDataset, DataLoader

df = pd.read_excel('data.xlsx')
X = df[['X', 'Y']].values.astype(np.float32)
y = df[['X', 'Y', 'Z']].values.astype(np.float32)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 转换数据为PyTorch的Tensor
X_train_tensor = torch.from_numpy(X_train)
y_train_tensor = torch.from_numpy(y_train)
X_test_tensor = torch.from_numpy(X_test)
y_test_tensor = torch.from_numpy(y_test)

# 创建数据集和数据加载器
train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
test_dataset = TensorDataset(X_test_tensor, y_test_tensor)

batch_size = 1
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)


# 定义神经网络模型
class MyModel(nn.Module):
    def __init__(self):
        super(MyModel, self).__init__()
        self.fc1 = nn.Linear(2, 64)  # 输入维度为2，输出维度为64
        self.fc2 = nn.Linear(64, 64)  # 输入维度为64，输出维度为64
        self.fc3 = nn.Linear(64, 3)   # 输入维度为64，输出维度为3，对应三维坐标点

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x

# 实例化模型
model = MyModel()

# 加载保存的模型参数
model.load_state_dict(torch.load('model_weights.pth'))

# 设置模型为评估模式
model.eval()

# 假设你有一个二维点集，存储在X_input中，X_input是一个张量
# 使用加载的模型参数生成对应的三维点集
with torch.no_grad():
    # 假设X_input是一个二维点集的张量，每一行代表一个二维点
    # 使用模型预测对应的三维点集
    Y_output = model(X_test_tensor)

# Y_output现在包含了模型根据输入二维点集生成的三维点集
print(Y_output)


df = pd.DataFrame(Y_output, columns=['X', 'Y', 'Z'])

df['Z'] = np.round(df['Z']).astype(int)

df['label'] = 0  # 先将所有点的label列设置为0
df.loc[df['Z'] == 2, 'label'] = 1  # 将Z坐标为2的点的label列设置为1

# 保存DataFrame到Excel文件
df.to_excel('output_points.xlsx', index=False)
