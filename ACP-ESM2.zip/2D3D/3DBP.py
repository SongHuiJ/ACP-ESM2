# 定义神经网络架构
import numpy as np
import pandas as pd
import torch
from matplotlib import pyplot as plt
from sklearn.metrics import precision_score, matthews_corrcoef, confusion_matrix, roc_auc_score, accuracy_score
from sklearn.model_selection import train_test_split
from torch import nn, optim

# 读取数据
from torch.utils.data import TensorDataset, DataLoader

df = pd.read_excel('data.xlsx')
X = df[['X', 'Y', 'Z']].values.astype(np.float32)
y = df['label'].values.astype(np.float32)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 转换数据为PyTorch的Tensor
X_train_tensor = torch.from_numpy(X_train)
y_train_tensor = torch.from_numpy(y_train)
X_test_tensor = torch.from_numpy(X_test)
y_test_tensor = torch.from_numpy(y_test)

# 创建数据集和数据加载器
train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
test_dataset = TensorDataset(X_test_tensor, y_test_tensor)

batch_size = 1
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

class SimpleNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(SimpleNN, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        return x

# 设置参数
input_size = 3  # 输入特征的维度
hidden_size = 64  # 隐藏层的大小
output_size = 1  # 输出的维度

# 创建神经网络实例
model = SimpleNN(input_size, hidden_size, output_size)

criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 训练模型
num_epochs = 50
for epoch in range(num_epochs):
    for inputs, labels in train_loader:
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs.squeeze(), labels)
        loss.backward()
        optimizer.step()

    print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}')

# 模型评估
model.eval()
with torch.no_grad():
    all_predictions = []
    all_labels = []

    for inputs, labels in test_loader:
        outputs = model(inputs)
        predicted = torch.round(outputs.squeeze()).numpy()
        if predicted.ndim == 0:
            predicted = np.array([predicted.item()])  # Convert 0-dimensional array to 1-dimensional
        all_predictions.extend(predicted)
        all_labels.extend(labels.numpy())

print(all_labels)
print(all_predictions)

# 将列表转换为NumPy数组
all_predictions = np.array(all_predictions)
all_labels = np.array(all_labels)

# 绘制三维散点图
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# 绘制预测值
ax.scatter(X_test[all_predictions == 1, 0], X_test[all_predictions == 1, 1], all_predictions[all_predictions == 1],
           c='#759ddb', marker='o', label='Predicted (1)', alpha=0.7, s=50)

ax.scatter(X_test[all_predictions == 0, 0], X_test[all_predictions == 0, 1], all_predictions[all_predictions == 0],
           c='#af8fd0', marker='o', label='Predicted (0)', alpha=0.7, s=50)

# 绘制真实值
ax.scatter(X_test[all_labels == 1, 0], X_test[all_labels == 1, 1], all_labels[all_labels == 1],
           c='#eca47c', marker='+', label='True (1)', s=30)

ax.scatter(X_test[all_labels == 0, 0], X_test[all_labels == 0, 1], all_labels[all_labels == 0],
           c='#f7df87', marker='+', label='True (0)', s=30)

ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Predicted/True Label')
ax.set_title('3D Distribution of Test Results')
ax.legend()
plt.show()

# 计算AUC
auc = roc_auc_score(all_labels, all_predictions)

# 计算ACC
acc = accuracy_score(all_labels, all_predictions)

# 计算混淆矩阵
tn, fp, fn, tp = confusion_matrix(all_labels, all_predictions).ravel()

# 计算SE、SP、Precision和MCC
se = tp / (tp + fn)
sp = tn / (tn + fp)
precision = precision_score(all_labels, all_predictions)
mcc = matthews_corrcoef(all_labels, all_predictions)

# 打印结果
print(f'AUC: {auc:.4f}')
print(f'ACC: {acc:.4f}')
print(f'Sensitivity (SE): {se:.4f}')
print(f'Specificity (SP): {sp:.4f}')
print(f'Precision: {precision:.4f}')
print(f'MCC: {mcc:.4f}')