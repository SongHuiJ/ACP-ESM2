import random
import time

import torch
import numpy as np
import pandas as pd
import torch.nn as nn
import torch.optim as optim
import torch.utils.data as Data
import transformers
from sklearn import metrics
from sklearn.metrics import roc_curve, roc_auc_score, matthews_corrcoef, confusion_matrix
from sklearn.metrics import matthews_corrcoef, confusion_matrix
from tqdm import tqdm
from transformers import BertTokenizer, AutoModel
from transformers import AutoTokenizer, EsmForProteinFolding
import torch.nn.functional as F
import os

df = pd.read_csv('D:\PythonProjects\ACP-ESM2\E2E-ACP\ACP606\\train.csv')
print('一共有{}条数据'.format(len(df)))
df.info()
use_df = df[:]
use_df.head(10)
sentences = list(use_df['feature'])
labels = list(use_df['label'])

df1 = pd.read_csv('D:\PythonProjects\ACP-ESM2\E2E-ACP\ACP606\\test.csv')
print('一共有{}条数据'.format(len(df1)))
df1.info()
use_df1 = df1[:]
use_df.head(10)
sentences1 = list(use_df1['feature'])
labels1 = list(use_df1['label'])


class MyDataSet(Data.Dataset):
    def __init__(self, data, label):
        self.data = data
        self.label = label
        self.tokenizer = AutoTokenizer.from_pretrained("facebook/esm2_t12_35M_UR50D", do_lower_case=False)
        # self.tokenizer = BertTokenizer(vocab_file='vocab.txt',model_max_len=17,do_lower_case=False)

    def __getitem__(self, idx):
        text = self.data[idx]
        label = self.label[idx]
        inputs = self.tokenizer(text, return_tensors="pt", padding="max_length", max_length=50, truncation=True)
        input_ids = inputs.input_ids.squeeze(0)
        # token_type_ids=inputs.token_type_ids.squeeze(0)
        attention_mask = inputs.attention_mask.squeeze(0)
        # return input_ids,token_type_ids,attention_mask,label
        return input_ids, attention_mask, label

    def __len__(self):
        return len(self.data)


train_dataset = MyDataSet(sentences, labels)
test_dataset = MyDataSet(sentences1, labels1)


class MyModel(nn.Module):
    def __init__(self, hidden_dim=128, output_dim=2):
        super(MyModel, self).__init__()
        self.bert_model = AutoModel.from_pretrained("facebook/esm2_t12_35M_UR50D")
        self.gru = nn.GRU(input_size=self.bert_model.config.hidden_size,
                          hidden_size=hidden_dim,
                          batch_first=True,
                          bidirectional=True,
                          num_layers=2
                          )
        self.fc = nn.Linear(in_features=hidden_dim * 2, out_features=output_dim)

    def forward(self, input_ids, attention_mask):
        pooled_output = self.bert_model(input_ids, attention_mask).pooler_output
        # output, _ = self.lstm(pooled_output.unsqueeze(0))
        # logits = self.fc(output.squeeze(0))
        output, _ = self.gru(pooled_output.unsqueeze(0))
        out = self.fc(output.squeeze(0))  # 获取最后一个时间步的输出
        return out


tpr_list = []
fpr_list = []
trainloader = Data.DataLoader(train_dataset, batch_size=64, shuffle=True)
testloader = Data.DataLoader(test_dataset, batch_size=64, shuffle=False)
# a = next(iter(trainloader))
# print(a[0],a[3])
# print(a[0].shape,a[3].shape),input()
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = MyModel()
# print(model)
# print(model),input()
# new_embeddings = nn.Embedding(num_embeddings=27,embedding_dim=768)
# model.bert.embeddings.word_embeddings = new_embeddings
model = model.to(device)
# print(model),input()
loss_fn = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=5e-6)
criterion = nn.CrossEntropyLoss().to(device)
epochs = 50
max_auc = 0


def train_model():
    for epoch in range(epochs):
        print("-------第 {} 轮训练开始-------".format(epoch + 1))
        model.train()
        total_train_loss = 0
        total_accuracy = 0
        for input_ids, attention_mask, label in tqdm(trainloader):
            input_ids, attention_mask, label = input_ids.to(device), attention_mask.to(device), label.to(device)
            pred = model(input_ids, attention_mask)
            loss = criterion(pred, label)  # batch_y类标签就好，不用one-hot形式
            total_train_loss = total_train_loss + loss.item()
            accuracy = (pred.argmax(1) == label).sum()
            total_accuracy = total_accuracy + accuracy
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        print("整体训练集上的Loss: {:.3f}".format(total_train_loss))
        print("整体训练集上的正确率: {:.3f}".format(total_accuracy / len(train_dataset)))
        torch.save(model.state_dict(), "./weights/classifier_weights_AntiCP2-alt.pth")


def main():
    start_time = time.time()
    train_model()
    end_time = time.time()
    duration = end_time - start_time
    print("代码运行时长", duration, "秒")


if __name__ == '__main__':
    main()
