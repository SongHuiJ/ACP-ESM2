import random

import torch
import numpy as np
import pandas as pd
import torch.nn as nn
import torch.optim as optim
import torch.utils.data as Data
import transformers
from sklearn import metrics
from sklearn.metrics import roc_curve, roc_auc_score, matthews_corrcoef, confusion_matrix
from sklearn.metrics import matthews_corrcoef, confusion_matrix
from tqdm import tqdm
from transformers import BertTokenizer, AutoModel
from transformers import AutoTokenizer, EsmForProteinFolding
import torch.nn.functional as F
import os

df = pd.read_csv('./AntiCP2/Alt-train.csv')
print('一共有{}条数据'.format(len(df)))
df.info()
use_df = df[:]
use_df.head(10)
sentences = list(use_df['feature'])
labels = list(use_df['label'])

df1 = pd.read_csv('./AntiCP2/Alt-val.csv')
print('一共有{}条数据'.format(len(df1)))
df1.info()
use_df1 = df1[:]
use_df.head(10)
sentences1 = list(use_df1['feature'])
labels1 = list(use_df1['label'])

class MyDataSet(Data.Dataset):
    def __init__(self, data, label):
        self.data = data
        self.label = label
        self.tokenizer = AutoTokenizer.from_pretrained("facebook/esm2_t12_35M_UR50D", do_lower_case=False)
        # self.tokenizer = BertTokenizer(vocab_file='vocab.txt',model_max_len=17,do_lower_case=False)

    def __getitem__(self, idx):
        text = self.data[idx]
        label = self.label[idx]
        inputs = self.tokenizer(text, return_tensors="pt", padding="max_length", max_length=50, truncation=True)
        input_ids = inputs.input_ids.squeeze(0)
        # token_type_ids=inputs.token_type_ids.squeeze(0)
        attention_mask = inputs.attention_mask.squeeze(0)
        # return input_ids,token_type_ids,attention_mask,label
        return input_ids, attention_mask, label

    def __len__(self):
        return len(self.data)

train_dataset = MyDataSet(sentences, labels)
test_dataset = MyDataSet(sentences1, labels1)

class MyModel(nn.Module):
    def __init__(self, hidden_dim=128, output_dim=2):
        super(MyModel, self).__init__()
        self.bert_model = AutoModel.from_pretrained("facebook/esm2_t12_35M_UR50D")
        self.gru = nn.GRU(input_size = self.bert_model.config.hidden_size,
                          hidden_size = hidden_dim,
                          batch_first=True,
                          bidirectional=True,
                          num_layers=2
                          )
        self.fc = nn.Linear(in_features = hidden_dim * 2, out_features = output_dim)

    def forward(self, input_ids, attention_mask):
        pooled_output = self.bert_model(input_ids, attention_mask).pooler_output
        # output, _ = self.lstm(pooled_output.unsqueeze(0))
        # logits = self.fc(output.squeeze(0))
        output, _ = self.gru(pooled_output.unsqueeze(0))
        out = self.fc(output.squeeze(0))  # 获取最后一个时间步的输出
        return out

tpr_list = []
fpr_list = []
trainloader = Data.DataLoader(train_dataset, batch_size=64, shuffle=True)
testloader = Data.DataLoader(test_dataset, batch_size=64, shuffle=False)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = MyModel()
model = model.to(device)
loss_fn = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=5e-6)
model.load_state_dict(torch.load('./weights/classifier_weights_AntiCP2-alt.pth'))

criterion = nn.CrossEntropyLoss().to(device)
epochs = 50
max_auc = 0

def test_model():
    # 测试步骤开始
    from sklearn.metrics import roc_auc_score
    import matplotlib.pyplot as plt
    from sklearn.metrics import roc_curve

    model.eval()
    in_predictions = []
    in_true_labels = []
    total_test_loss = 0
    total_test_accuracy = 0
    with torch.no_grad():
        for input_ids, attention_mask, label in tqdm(testloader):
            input_ids, attention_mask, label = input_ids.to(device), attention_mask.to(device), label.to(device)
            pred = model(input_ids, attention_mask)
            pred_proba = F.softmax(pred, dim=1)
            in_predictions.append(pred_proba.cpu().numpy())
            in_true_labels.append(label.cpu().numpy())
            loss = criterion(pred, label)  # batch_y类标签就好，不用one-hot形式
            total_test_loss = total_test_loss + loss.item()
            accuracy = (pred.argmax(1) == label).sum()
            total_test_accuracy = total_test_accuracy + accuracy
            accuracy_v = total_test_accuracy/len(test_dataset)
        in_predictions = np.concatenate(in_predictions)
        in_true_labels = np.concatenate(in_true_labels)
    print("整体测试集上的Loss: {:.3f}".format(total_test_loss))
    print("整体测试集上的正确率: {:.3f}".format(accuracy_v))

    # ROC 曲线下面积等于auc值
    auc = roc_auc_score(in_true_labels, in_predictions[:, 1])
    print("AUC: {:.3f}".format(auc))

    from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

    # 计算准确率
    accuracy = accuracy_score(in_true_labels, np.argmax(in_predictions, axis=1))

    # 计算精度
    precision = precision_score(in_true_labels, np.argmax(in_predictions, axis=1))

    # 计算召回率
    recall = recall_score(in_true_labels, np.argmax(in_predictions, axis=1))

    # 计算 F1 分数
    f1 = f1_score(in_true_labels, np.argmax(in_predictions, axis=1))

    # 计算混淆矩阵
    confusion = confusion_matrix(in_true_labels, np.argmax(in_predictions, axis=1))
    mcc = matthews_corrcoef(in_true_labels, np.argmax(in_predictions, axis=1))

    print("准确率 (Accuracy): {:.3f}".format(accuracy))
    print("精度 (Precision): {:.3f}".format(precision))
    print("召回率 (Recall): {:.3f}".format(recall))
    print("F1 分数 (F1-score): {:.3f}".format(f1))
    print("混淆矩阵 (Confusion Matrix):\n", confusion)
    tn, fp, fn, tp = confusion.ravel()
    specificity = tn / (tn + fp)
    sensitivity = tp / (tp + fn)
    print("specificity: {:.3f}".format(specificity))
    print("sensitivity: {:.3f}".format(sensitivity))
    print("mcc: {:.3f}".format(mcc))
    # 绘制 ROC 曲线
    names = 'songclassifier_AVP_ROC'
    colors = 'crimson'  # 这个是曲线的颜色，几个模型就需要几个颜色哦！'orange','lawngreen'
    plt.figure(figsize=(20, 20), dpi=100)
    fpr, tpr, thresholds = roc_curve(in_true_labels, in_predictions[:, 1], pos_label=1)
    plt.plot(fpr, tpr, lw=5, label='{} (AUC={:.3f})'.format(names, auc), color=colors)
    plt.plot([0, 1], [0, 1], '--', lw=5, color='grey')
    plt.axis('square')
    plt.xlim([0, 1])
    plt.ylim([0, 1])
    plt.xlabel('False Positive Rate', fontsize=20)
    plt.ylabel('True Positive Rate', fontsize=20)
    plt.title('ROC Curve', fontsize=25)
    plt.legend(loc='lower right', fontsize=20)
    plt.savefig('./Figures/songclassifier_ACP_ROC.png')


def main():
    test_model()


if __name__ == '__main__':
    main()