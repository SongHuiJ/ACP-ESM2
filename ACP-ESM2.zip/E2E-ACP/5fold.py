import random
import torch
import numpy as np
import pandas as pd
import torch.nn as nn
import torch.optim as optim
import torch.utils.data as Data
from sklearn.metrics import matthews_corrcoef
from transformers import AutoTokenizer, AutoModel
import torch.nn.functional as F
from tqdm import tqdm
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import StratifiedKFold

class MyModel(nn.Module):
    def __init__(self, hidden_dim=128, output_dim=2):
        super(MyModel, self).__init__()
        self.bert_model = AutoModel.from_pretrained("facebook/esm2_t12_35M_UR50D")
        self.gru = nn.GRU(input_size = self.bert_model.config.hidden_size,
                          hidden_size = hidden_dim,
                          batch_first=True,
                          bidirectional=True,
                          num_layers=2
                          )
        self.fc = nn.Linear(in_features = hidden_dim * 2, out_features = output_dim)

    def forward(self, input_ids, attention_mask):
        pooled_output = self.bert_model(input_ids, attention_mask).pooler_output
        # output, _ = self.lstm(pooled_output.unsqueeze(0))
        # logits = self.fc(output.squeeze(0))
        output, _ = self.gru(pooled_output.unsqueeze(0))
        out = self.fc(output.squeeze(0))  # 获取最后一个时间步的输出
        return out


class MyDataSet(Data.Dataset):
    def __init__(self, data, label):
        self.data = data
        self.label = label
        self.tokenizer = AutoTokenizer.from_pretrained("facebook/esm2_t12_35M_UR50D", do_lower_case=False)
        # self.tokenizer = BertTokenizer(vocab_file='vocab.txt',model_max_len=17,do_lower_case=False)

    def __getitem__(self, idx):
        text = self.data[idx]
        label = self.label[idx]
        inputs = self.tokenizer(text, return_tensors="pt", padding="max_length", max_length=207, truncation=True) #207
        input_ids = inputs.input_ids.squeeze(0)
        attention_mask = inputs.attention_mask.squeeze(0)
        label = int(label)
        label = torch.tensor(label)  # Convert label to PyTorch tensor
        return input_ids, attention_mask, label

    def __len__(self):
        return len(self.data)


def main():
    all_auc = []
    all_accuracy = []
    all_mcc = []
    all_precision = []
    all_recall = []
    all_sp = []
    all_sn = []
    df = pd.read_csv('./acp240/acp240.csv')
    print('一共有{}条数据'.format(len(df)))
    df.info()
    use_df = df[:]
    use_df.head(10)
    # 提取特征列和标签列到列表中
    features = df['feature'].tolist()
    labels = df['label'].tolist()
    # 创建5折交叉验证对象
    num_cross_val = 5
    skf = StratifiedKFold(n_splits=num_cross_val, shuffle=True, random_state=42)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    criterion = nn.CrossEntropyLoss().to(device)
    epochs = 10
    max_auc = 0
    # optimizer = optim.Adam(model.parameters(), lr=5e-6)
    for fold, (train_index, test_index) in enumerate(skf.split(features, labels)):
        model = MyModel()
        model = model.to(device)
        optimizer = optim.Adam(model.parameters(), lr=1e-4)
        train_sentences = [features[i] for i in train_index if features[i] != "feature" and labels[i] != "label"]
        train_labels = [labels[i] for i in train_index if features[i] != "feature" and labels[i] != "label"]
        test_sentences = [features[i] for i in test_index if features[i] != "feature" and labels[i] != "label"]
        test_labels = [labels[i] for i in test_index if features[i] != "feature" and labels[i] != "label"]
        print("-------第 {} 折交叉验证开始-------".format(fold + 1))
        # 创建训练和测试数据集
        train_dataset = MyDataSet(train_sentences, train_labels)
        trainloader = Data.DataLoader(train_dataset, batch_size=32, shuffle=False)
        test_dataset = MyDataSet(test_sentences, test_labels)
        testloader = Data.DataLoader(test_dataset, batch_size=32, shuffle=False)
        # 调用训练和评估函数
        for epoch in range(epochs):
            print("-------第 {} 轮训练开始-------".format(epoch + 1))
            model.train()
            total_train_loss = 0
            total_accuracy = 0
            for input_ids, attention_mask, label in tqdm(trainloader):
                input_ids, attention_mask, label = input_ids.to(device), attention_mask.to(device), label.to(device)
                pred = model(input_ids, attention_mask)
                loss = criterion(pred, label)  # batch_y类标签就好，不用one-hot形式
                total_train_loss = total_train_loss + loss.item()
                accuracy = (pred.argmax(1) == label).sum()
                total_accuracy = total_accuracy + accuracy
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
            print("整体训练集上的Loss: {:.3f}".format(total_train_loss))
            print("整体训练集上的正确率: {:.3f}".format(total_accuracy / len(train_dataset)))
        # 测试步骤开始
        from sklearn.metrics import roc_auc_score
        model.eval()
        in_predictions = []
        in_true_labels = []
        total_test_loss = 0
        total_test_accuracy = 0
        with torch.no_grad():
            for input_ids, attention_mask, label in tqdm(testloader):
                input_ids, attention_mask, label = input_ids.to(device), attention_mask.to(device), label.to(device)
                pred = model(input_ids, attention_mask)
                pred_proba = F.softmax(pred, dim=1)
                in_predictions.append(pred_proba.cpu().numpy())
                in_true_labels.append(label.cpu().numpy())
                loss = criterion(pred, label)  # batch_y类标签就好，不用one-hot形式
                total_test_loss = total_test_loss + loss.item()
                accuracy = (pred.argmax(1) == label).sum()
                total_test_accuracy = total_test_accuracy + accuracy
                accuracy_v = total_test_accuracy / len(test_dataset)
            in_predictions = np.concatenate(in_predictions)
            in_true_labels = np.concatenate(in_true_labels)
        print("整体测试集上的Loss: {:.3f}".format(total_test_loss))
        print("整体测试集上的正确率: {:.3f}".format(accuracy_v))

        # ROC 曲线下面积等于auc值
        auc = roc_auc_score(in_true_labels, in_predictions[:, 1])
        print("AUC: {:.3f}".format(auc))
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
        # 计算准确率
        accuracy = accuracy_score(in_true_labels, np.argmax(in_predictions, axis=1))
        # 计算精度
        precision = precision_score(in_true_labels, np.argmax(in_predictions, axis=1))
        # 计算召回率
        recall = recall_score(in_true_labels, np.argmax(in_predictions, axis=1))
        # 计算 F1 分数
        f1 = f1_score(in_true_labels, np.argmax(in_predictions, axis=1))
        # 计算混淆矩阵
        confusion = confusion_matrix(in_true_labels, np.argmax(in_predictions, axis=1))
        mcc = matthews_corrcoef(in_true_labels, np.argmax(in_predictions, axis=1))
        print("准确率 (Accuracy): {:.3f}".format(accuracy))
        print("精度 (Precision): {:.3f}".format(precision))
        print("召回率 (Recall): {:.3f}".format(recall))
        print("F1 分数 (F1-score): {:.3f}".format(f1))
        print("混淆矩阵 (Confusion Matrix):\n", confusion)
        tn, fp, fn, tp = confusion.ravel()
        specificity = tn / (tn + fp)
        sensitivity = tp / (tp + fn)
        print("specificity: {:.3f}".format(specificity))
        print("sensitivity: {:.3f}".format(sensitivity))
        print("mcc: {:.3f}".format(mcc))
        all_auc.append(auc)
        all_accuracy.append(accuracy)
        all_mcc.append(mcc)
        all_precision.append(precision)
        all_recall.append(recall)
        all_sp.append(specificity)
        all_sn.append(sensitivity)
    average_auc = np.mean(all_auc)
    average_accuracy = np.mean(all_accuracy)
    average_mcc = np.mean(all_mcc)
    average_precision = np.mean(all_precision)
    average_recall = np.mean(all_recall)
    average_sp = np.mean(all_sp)
    average_sn = np.mean(all_sn)
    # 计算其他平均性能指标
    print("平均AUC: {:.3f}".format(average_auc))
    print("平均准确率: {:.3f}".format(average_accuracy))
    print("平均mcc: {:.3f}".format(average_mcc))
    print("平均precision: {:.3f}".format(average_precision))
    print("平均recall: {:.3f}".format(average_recall))
    print("平均sp: {:.3f}".format(average_sp))
    print("平均sn: {:.3f}".format(average_sn))




if __name__ == '__main__':
    main()
